import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JPanel;

public class Display extends JPanel implements Runnable{
	
	private static final long serialVersionUID = 1L;

	
	private static final int Width=800,height=600;
	private Thread thread;
	private boolean running =false;
	
	private SnakeBody b;
	private ArrayList<SnakeBody>snake;
	
	private Toads toad;
	private ArrayList<Toads>toads;
	
	
	private int xCoordinate=10,yCoordinate=10;
	private int size=5;
	
	private boolean right=false,left=false,up=false,down=false;
	
	private int ticks=0;
	
	private Key key;
	
	
	private Random r;
	
	public Display(){ 
		
		
	this.setFocusable(true);
	key=new Key();
	this.addKeyListener(key);
	this.setPreferredSize(new Dimension(Width,height));
	this.setBackground(Color.BLACK);
	
	snake=new ArrayList<SnakeBody>();
	toads =new ArrayList<Toads>();
	r=new Random();
		
		start();
	}
	
	
	public void tick(){
		if(snake.size() == 0){
			b=new SnakeBody(xCoordinate,yCoordinate,10);
			snake.add(b);
		}
		
		if(toads.size() == 0){
			int xCoordinate = r.nextInt(20);
			int yCoordinate = r.nextInt(20);
			
			toad=new Toads(xCoordinate,yCoordinate,10);
			toads.add(toad);
		}

		for (int i=0;i<toads.size();i++){
			
			if(xCoordinate == toads.get(i).getxCoor() && yCoordinate ==toads.get(i).getyCoor()){
			
				size ++;
				toads.remove(i);
				i--; 
		}
		ticks++;
		
		if(ticks > 250000){
			if(right) xCoordinate++;
			if(left) xCoordinate--;
			if(up) yCoordinate--;
			if(down) yCoordinate++;
			
			ticks=0;
			
			b=new SnakeBody(xCoordinate,yCoordinate,10);
			snake.add(b);
			
			if(snake.size()> size){
				
				snake.remove(i);
			}
			
		}
		
		
	}
	}
	
	public void paint(Graphics g){
		g.clearRect(0, 0, Width, height);
		
		for(int i=0;i<snake.size();i++){
			
		snake.get(i).draw(g);
		}
		
		for (int i=0;i<toads.size();i++){
			toads.get(i).draw(g);
			
		}
		}
		
		
		
	
	
	public void start(){
		running=true;
		thread=new Thread(this,"Game Loop");
		thread.start();
	}
	

	@Override
	public void run() {
		while (running){
		tick();
		repaint();
	
		}
	}
	
	public class Key implements KeyListener{

		@Override
		public void keyPressed(KeyEvent e) {
			int key=e.getKeyCode();
			
			if(key == KeyEvent.VK_RIGHT && (!left)){
				right=true;
				up=false;
				down=false;
				
			}
			
			
			if(key == KeyEvent.VK_LEFT && (!right)){
				left=true;
				up=false;
				down=false;
				
			}
			
			if(key == KeyEvent.VK_UP && (!down)){
				right=false;
				left=false;
				up=true;
				
				
			}
			
			if(key == KeyEvent.VK_DOWN && (!up)){
				right=false;
				left=false;
				down=true;
				
				
			}
			
		}

		
		public void keyReleased(KeyEvent arg0) {
			
			
		}

	
		public void keyTyped(KeyEvent arg0) {
			
			
		}
		
	}
	
	public class Buttion implements ActionListener{

		
		public void actionPerformed(ActionEvent e) {
			
			
		}
		
		
		
	}
	
	
}