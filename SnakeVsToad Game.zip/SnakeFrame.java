
import java.awt.GridLayout;

import javax.swing.JFrame;

public class SnakeFrame extends JFrame {
	private static final long serialVersionUID = 1L;
	
	
	
	
	public SnakeFrame(){
		this.setTitle("SnakeGame.Made by Setu Nath");
		this.setLayout(new GridLayout(1,1,0,0));
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);
		
	    
		
			
			
		init();
		
		
	}




	public  void init() {
		Display d=new Display();
		this.add(d);
		
		
		
pack();
this.setLocationRelativeTo(null);
this.setVisible(true);
		
	
	}
	

}
