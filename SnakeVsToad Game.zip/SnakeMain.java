
public class SnakeMain {
	public static void main(String[]args){
	@SuppressWarnings("unused")
	SnakeFrame S;
	S = new SnakeFrame();

}
}

